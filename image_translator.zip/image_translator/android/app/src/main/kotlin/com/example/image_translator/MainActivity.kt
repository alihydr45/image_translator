package com.example.image_translator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
