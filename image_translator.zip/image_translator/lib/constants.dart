

String kApiKey = 'K84978975988957';
String kUri = 'https://api.ocr.space/parse/image';